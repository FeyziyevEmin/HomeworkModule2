package lesson_6.HomeWork6;

interface BookFilter {
    boolean filter(Library<?>.Book book);
}
