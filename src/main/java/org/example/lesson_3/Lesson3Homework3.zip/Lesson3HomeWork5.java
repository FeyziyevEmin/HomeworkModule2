package lesson_3;

public class Lesson3HomeWork5 {
    public static void main(String[] args) {
        String original = "OpenAI";
        StringBuilder ivers = new StringBuilder(original);
        ivers.reverse();
        System.out.println("Tersine cevrilmis String: " + ivers);
    }
}
