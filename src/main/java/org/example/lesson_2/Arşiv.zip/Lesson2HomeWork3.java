package lesson_2;

import javax.xml.transform.Source;
import java.util.Scanner;

public class Lesson2HomeWork3 {
    public static void main(String[] args){
        Scanner scanner=new Scanner(System.in);
        System.out.println("Add to number");
        int a= scanner.nextInt();

        for (int i = 0; i < a; i++) {
            System.out.println(i);
        }
    }
}
