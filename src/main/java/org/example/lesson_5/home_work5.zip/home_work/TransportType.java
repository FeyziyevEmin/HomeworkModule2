package lesson_5.home_work;

public enum TransportType {
    TAXI, BUS, BICYCLE, SCOOTER;
}
